//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import java.util.Scanner;

public class Main {
    public static boolean isVowel(char ch) { //==>// memeriksa apakah karakter yang di input adlah huruf vokal
        char upperCh = Character.toUpperCase(ch);
        return (upperCh == 'A' || upperCh == 'E' || upperCh == 'I' || upperCh == 'O' || upperCh == 'U');
    }
    public static String numberToText(char num) {
        switch (num) {
            case '0': return "NOL";
            case '1': return "SATU";
            case '2': return "DUA";
            case '3': return "TIGA";
            case '4': return "EMPAT";
            case '5': return "LIMA";
            case '6': return "ENAM";
            case '7': return "TUJUH";
            case '8': return "DELAPAN";
            case '9': return "SEMBILAN";
            default: return String.valueOf(num); // Jika bukan angka, kembalikan karakter aslinya
        }
    }
    public static String processString(String input) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < input.length(); i++) {
            char ch = input.charAt(i);
            ch = Character.toUpperCase(ch); //-->// Ubah karakter menjadi uppercase
            if (isVowel(ch)) { //-->//// Jika huruf vokal, skip
                continue;
            }
            if (Character.isDigit(ch)) { //-->//// Jika karakter adalah angka, ubah menjadi string teks angka
                result.append(numberToText(ch));
            } else {
                // Jika bukan vokal dan bukan angka, tambahkan ke hasil
                result.append(ch);
            }
        }

        return result.toString();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input string dari pengguna
        System.out.print("Masukkan sebuah string: ");
        String input = scanner.nextLine();

        // Proses string dan tampilkan hasilnya
        String output = processString(input);
        System.out.println("Hasil: " + output);
    }
}
