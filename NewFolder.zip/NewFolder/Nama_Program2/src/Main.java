//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import java.util.Scanner;

        public class Main {
            // Fungsi untuk mengecek apakah bilangan adalah bilangan prima
            public static boolean isPrime(int num) { //==>/// memeriksa untuk bilangan ini apakah bilangan prima
                if (num <= 1) return false;
                for (int i = 2; i <= Math.sqrt(num); i++) {
                    if (num % i == 0) return false;
                }
                return true;
            }
            // Fungsi untuk menampilkan bilangan genap/ganjil dan cek prima
            public static void checkEvenOddPrime(int A, int B) { //==>// mendeskripsikan apakah bilangan A dan B itu genap atau ganjil dan menambahkan "prime" jika bilangan tersebut adalah bilangan prima
            for (int x = A + 1; x <= B; x++) {
                String result = x + " is ";
                // Cek genap atau ganjil
                    if (x % 2 == 0) {
                        result += "even";
                    } else {
                        result += "odd";
                    }
                    // Cek apakah bilangan prima
                    if (isPrime(x)) {
                        result += " prime";
                    }
                    // Cetak hasil
                    System.out.println(result);
                }
            }

            public static void main(String[] args) {
                Scanner scanner = new Scanner(System.in);

                // Input bilangan A dan B
                System.out.print("Masukkan bilangan A: ");
                int A = scanner.nextInt();
                System.out.print("Masukkan bilangan B: ");
                int B = scanner.nextInt();
                // Menampilkan hasil
                checkEvenOddPrime(A, B);
            }
        }
